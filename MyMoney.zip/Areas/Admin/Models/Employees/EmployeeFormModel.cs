﻿namespace MyMoney.Areas.Admin.Models.Employees
{
    using MyMoney.Services.Users;
    using System.ComponentModel.DataAnnotations;

    public class EmployeeFormModel
    {
        //[Required]
        //[StringLength(3, MinimumLength = 3, ErrorMessage = "The currency code has to be exactly 3 characters.")]
        //public string Code { get; init; }

        public IEnumerable<UserServiceModel> Users;
    }
}
