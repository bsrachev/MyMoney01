﻿using MyMoney.Services.Offices;

namespace MyMoney.Areas.Admin.Models.Offices
{
    public class AllOfficesQueryModel
    {
        public IEnumerable<OfficeServiceModel> Offices;

        public int? OfficeId;
    }
}
