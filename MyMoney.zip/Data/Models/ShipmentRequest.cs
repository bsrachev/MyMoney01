﻿namespace MyMoney.Data.Models
{
    public class ShipmentRequest : BaseShipment
    {
        public string SystemComment { get; set; }
    }
}
