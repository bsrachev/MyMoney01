﻿namespace MyMoney
{
    public class WebConstants
    {
        public const string GlobalSuccessKey = "GlobalSuccess";

        public const string GlobalErrorKey = "GlobalError";

        public class Cache
        {
            //public const string LatestCarsCacheKey = nameof(LatestCarsCacheKey); TODO
        }
    }
}
