﻿using MyMoney.Services.Offices;
using MyMoney.Services.Shipments;
using MyMoney.Services.Users;

namespace MyMoney.Models.Shipments
{
    public class NewShipmentFormModel
    {
        public ShipmentRequestServiceModel Request { get; set; }

        public CreateShipmentFormModel NewShipment { get; set; }

        public IEnumerable<UserServiceModel> DeliveryEmployeesList { get; set; }

        public IEnumerable<UserServiceModel> ClientsList { get; set; }

        public IEnumerable<OfficeServiceModel> OfficesList { get; set; }
    }
}
