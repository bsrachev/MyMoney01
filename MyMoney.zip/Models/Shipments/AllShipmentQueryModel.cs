﻿using MyMoney.Services.Shipments;

namespace MyMoney.Models.Shipments
{
    public class AllShipmentQueryModel
    {
        public IEnumerable<ShipmentServiceModel> Shipments { get; set; }

        public IEnumerable<ShipmentRequestServiceModel> ShipmentRequests { get; set; }
    }
}
