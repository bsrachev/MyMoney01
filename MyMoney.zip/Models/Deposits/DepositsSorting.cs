﻿namespace NBUniforms.Models
{
    public enum DepositsSorting
    {
        Model = 0,
        LastAdded = 1,
        FirstAdded = 2,
        TheMostExpensive = 3,
        TheCheapest = 4
    }
}
